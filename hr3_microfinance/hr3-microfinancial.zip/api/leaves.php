<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// Get ID from query string if available
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

// Handle GET requests
if ($method === 'GET') {
    if ($id) {
        // Get one leave
        $stmt = $conn->prepare("SELECT * FROM leaves WHERE id = ?");
        $stmt->execute([$id]);
        $leave = $stmt->fetch();
        if ($leave) {
            echo json_encode($leave);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Leave not found']);
        }
    } else {
        // Get all leaves
        $stmt = $conn->query("SELECT * FROM leaves ORDER BY created_at DESC");
        echo json_encode($stmt->fetchAll());
    }
    exit;
}

// Handle POST requests (create new leave)
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['employee_name'], $data['leave_type'], $data['from_date'], $data['to_date'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO leaves (employee_name, leave_type, from_date, to_date) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        $data['employee_name'],
        $data['leave_type'],
        $data['from_date'],
        $data['to_date']
    ]);

    echo json_encode(['message' => 'Leave applied successfully']);
    exit;
}

// Handle PUT requests (update leave)
if ($method === 'PUT') {
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing leave ID']);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['employee_name'], $data['leave_type'], $data['from_date'], $data['to_date'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("UPDATE leaves SET employee_name = ?, leave_type = ?, from_date = ?, to_date = ? WHERE id = ?");
    $stmt->execute([
        $data['employee_name'],
        $data['leave_type'],
        $data['from_date'],
        $data['to_date'],
        $id
    ]);

    echo json_encode(['message' => 'Leave updated successfully']);
    exit;
}

// Handle DELETE requests
if ($method === 'DELETE') {
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing leave ID']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM leaves WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode(['message' => 'Leave deleted successfully']);
    exit;
}

// Handle OPTIONS preflight
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Default response for unsupported methods
http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>
