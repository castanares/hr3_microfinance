<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

// GET all or one
if ($method === 'GET') {
    if ($id) {
        $stmt = $conn->prepare("SELECT * FROM timesheets WHERE id = ?");
        $stmt->execute([$id]);
        $ts = $stmt->fetch();
        if ($ts) {
            echo json_encode($ts);
        } else {
            http_response_code(404);
            echo json_encode(['error'=>'Timesheet not found']);
        }
    } else {
        $stmt = $conn->query("SELECT * FROM timesheets ORDER BY created_at DESC");
        echo json_encode($stmt->fetchAll());
    }
    exit;
}

// POST (create new)
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['employee_name'], $data['shift_date'], $data['shift_type'], $data['status'])) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO timesheets (employee_name, shift_date, shift_type, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        $data['employee_name'],
        $data['shift_date'],
        $data['shift_type'],
        $data['status']
    ]);

    echo json_encode(['message'=>'Timesheet added successfully']);
    exit;
}

// PUT (update)
if ($method === 'PUT') {
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing timesheet ID']);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['employee_name'], $data['shift_date'], $data['shift_type'], $data['status'])) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("UPDATE timesheets SET employee_name=?, shift_date=?, shift_type=?, status=? WHERE id=?");
    $stmt->execute([
        $data['employee_name'],
        $data['shift_date'],
        $data['shift_type'],
        $data['status'],
        $id
    ]);

    echo json_encode(['message'=>'Timesheet updated successfully']);
    exit;
}

// DELETE
if ($method === 'DELETE') {
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing timesheet ID']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM timesheets WHERE id=?");
    $stmt->execute([$id]);

    echo json_encode(['message'=>'Timesheet deleted successfully']);
    exit;
}

// OPTIONS preflight
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Default response
http_response_code(405);
echo json_encode(['error'=>'Method not allowed']);
?>
