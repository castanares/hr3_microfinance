<?php
// api/attendance.php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // allow frontend
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include "db.php";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":
        if (isset($_GET['id'])) {
            $stmt = $conn->prepare("SELECT * FROM attendance WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode($data);
        } else {
            $stmt = $conn->query("SELECT * FROM attendance ORDER BY date DESC");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }
        break;

    case "POST":
        $input = json_decode(file_get_contents("php://input"), true);
        if (!$input) {
            echo json_encode(["error" => "Invalid input"]);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO attendance (employee_name, date, clock_in, clock_out, status) 
                                VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $input['employee_name'],
            $input['date'],
            $input['clock_in'],
            $input['clock_out'],
            $input['status']
        ]);

        echo json_encode(["message" => "Attendance added successfully"]);
        break;

    case "PUT":
        parse_str($_SERVER['QUERY_STRING'], $params);
        $id = $params['id'] ?? null;

        if (!$id) {
            echo json_encode(["error" => "ID required"]);
            exit;
        }

        $input = json_decode(file_get_contents("php://input"), true);

        $stmt = $conn->prepare("UPDATE attendance 
                                SET employee_name=?, date=?, clock_in=?, clock_out=?, status=? 
                                WHERE id=?");
        $stmt->execute([
            $input['employee_name'],
            $input['date'],
            $input['clock_in'],
            $input['clock_out'],
            $input['status'],
            $id
        ]);

        echo json_encode(["message" => "Attendance updated successfully"]);
        break;

    case "DELETE":
        parse_str($_SERVER['QUERY_STRING'], $params);
        $id = $params['id'] ?? null;

        if (!$id) {
            echo json_encode(["error" => "ID required"]);
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM attendance WHERE id=?");
        $stmt->execute([$id]);

        echo json_encode(["message" => "Attendance deleted successfully"]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
        break;
}
?>
