<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

// Handle GET
if($method === 'GET'){
    if($id){ // Get one claim
        $stmt = $conn->prepare("SELECT * FROM claims WHERE id = ?");
        $stmt->execute([$id]);
        $claim = $stmt->fetch();
        if($claim){
            echo json_encode($claim);
        } else {
            http_response_code(404);
            echo json_encode(['error'=>'Claim not found']);
        }
    } else { // Get all claims
        $stmt = $conn->query("SELECT * FROM claims ORDER BY created_at DESC");
        echo json_encode($stmt->fetchAll());
    }
    exit;
}

// Handle POST (create new claim)
if($method === 'POST'){
    $data = json_decode(file_get_contents("php://input"), true);

    if(!isset($data['employee_name'], $data['claim_type'], $data['amount'], $data['claim_date'])){
        http_response_code(400);
        echo json_encode(['error'=>'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO claims (employee_name, claim_type, amount, claim_date, status, created_at) VALUES (?, ?, ?, ?, 'Pending', NOW())");
    $stmt->execute([
        $data['employee_name'],
        $data['claim_type'],
        $data['amount'],
        $data['claim_date']
    ]);

    echo json_encode(['message'=>'Claim submitted successfully']);
    exit;
}

// Handle PUT (update existing claim)
if($method === 'PUT'){
    if(!$id){
        http_response_code(400);
        echo json_encode(['error'=>'Missing claim ID']);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);

    if(!isset($data['employee_name'], $data['claim_type'], $data['amount'], $data['claim_date'])){
        http_response_code(400);
        echo json_encode(['error'=>'Missing required fields']);
        exit;
    }

    $stmt = $conn->prepare("UPDATE claims SET employee_name = ?, claim_type = ?, amount = ?, claim_date = ? WHERE id = ?");
    $stmt->execute([
        $data['employee_name'],
        $data['claim_type'],
        $data['amount'],
        $data['claim_date'],
        $id
    ]);

    echo json_encode(['message'=>'Claim updated successfully']);
    exit;
}

// Handle DELETE
if($method === 'DELETE'){
    if(!$id){
        http_response_code(400);
        echo json_encode(['error'=>'Missing claim ID']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM claims WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode(['message'=>'Claim deleted successfully']);
    exit;
}

// Fallback
http_response_code(405);
echo json_encode(['error'=>'Method not allowed']);
