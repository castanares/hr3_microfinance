<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php'; // this defines $conn

$method = $_SERVER["REQUEST_METHOD"];

// GET: fetch all shifts or single shift
if ($method === "GET") {
    if (isset($_GET['id'])) {
        $stmt = $conn->prepare("
            SELECT s.id, s.attendance_id, s.shift_type, s.shift_date,
                   a.employee_name, a.date AS attendance_date, a.status
            FROM shifts s
            LEFT JOIN attendance a ON s.attendance_id = a.id
            WHERE s.id = ?
        ");
        $stmt->execute([$_GET['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
    } else {
        $stmt = $conn->query("
            SELECT s.id, s.attendance_id, s.shift_type, s.shift_date,
                   a.employee_name, a.date AS attendance_date, a.status
            FROM shifts s
            LEFT JOIN attendance a ON s.attendance_id = a.id
            ORDER BY s.shift_date DESC
        ");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    exit;
}

// POST: create a new shift
if ($method === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['attendance_id'], $data['shift_type'], $data['shift_date'])) {
        http_response_code(400);
        echo json_encode(["error" => "Missing required fields"]);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO shifts (attendance_id, shift_type, shift_date) VALUES (?, ?, ?)");
    $stmt->execute([
        $data['attendance_id'],
        $data['shift_type'],
        $data['shift_date']
    ]);

    echo json_encode(["message" => "Shift assigned successfully"]);
    exit;
}

// PUT: update a shift
if ($method === "PUT") {
    $id = $_GET['id'] ?? null;
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$id || !isset($data['attendance_id'], $data['shift_type'], $data['shift_date'])) {
        http_response_code(400);
        echo json_encode(["error" => "Missing ID or required fields"]);
        exit;
    }

    $stmt = $conn->prepare("UPDATE shifts SET attendance_id=?, shift_type=?, shift_date=? WHERE id=?");
    $stmt->execute([
        $data['attendance_id'],
        $data['shift_type'],
        $data['shift_date'],
        $id
    ]);

    echo json_encode(["message" => "Shift updated successfully"]);
    exit;
}

// DELETE: delete a shift
if ($method === "DELETE") {
    $id = $_GET['id'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["error" => "Missing ID"]);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM shifts WHERE id=?");
    $stmt->execute([$id]);

    echo json_encode(["message" => "Shift deleted successfully"]);
    exit;
}
?>
