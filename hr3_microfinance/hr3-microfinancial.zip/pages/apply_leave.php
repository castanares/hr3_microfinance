<?php
include '../layout/Layout.php';
date_default_timezone_set('Asia/Manila');

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <i class="bx bx-calendar-alt text-red-600 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">Apply Leave</h1>
        </div>
        <span class="text-sm text-gray-500">Today: ' . date("F d, Y") . '</span>
    </div>

    <!-- Button to Open Modal -->
    <div class="mb-6 text-right">
        <button id="openModalBtn" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition">
            Apply Leave
        </button>
    </div>

    <!-- Modal -->
    <div id="leaveModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white rounded-xl shadow-lg w-full max-w-md p-6 relative">
            <button id="closeModalBtn" class="absolute top-3 right-3 text-gray-500 hover:text-gray-800 text-xl">&times;</button>
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Apply Leave</h2>
            <form id="applyLeaveForm">
                <input type="hidden" id="leaveId" value="">
                <div class="mb-3">
                    <label class="block text-gray-700 font-semibold mb-1">Employee</label>
                    <input type="text" id="employee" class="w-full border rounded-lg p-2" placeholder="Employee Name">
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 font-semibold mb-1">Leave Type</label>
                    <select id="leaveType" class="w-full border rounded-lg p-2">
                        <option value="">Select Leave Type</option>
                        <option value="Sick Leave">Sick Leave</option>
                        <option value="Vacation Leave">Vacation Leave</option>
                        <option value="Emergency Leave">Emergency Leave</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 font-semibold mb-1">From</label>
                    <input type="date" id="fromDate" class="w-full border rounded-lg p-2" value="' . date("Y-m-d") . '">
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 font-semibold mb-1">To</label>
                    <input type="date" id="toDate" class="w-full border rounded-lg p-2" value="' . date("Y-m-d") . '">
                </div>
                <div class="flex justify-end gap-2 mt-4">
                    <button type="button" id="cancelBtn" class="px-4 py-2 rounded-lg border hover:bg-gray-100 transition">Cancel</button>
                    <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition">Submit</button>
                </div>
                <p id="msg" class="mt-3 font-semibold text-green-600"></p>
            </form>
        </div>
    </div>

    <!-- Applied Leaves Table -->
    <div class="overflow-x-auto bg-white rounded-xl shadow p-4 mt-6">
        <table class="min-w-full border border-gray-200">
            <thead>
                <tr class="bg-gray-100 text-center">
                    <th class="px-4 py-2 border">Employee</th>
                    <th class="px-4 py-2 border">Leave Type</th>
                    <th class="px-4 py-2 border">From</th>
                    <th class="px-4 py-2 border">To</th>
                    <th class="px-4 py-2 border">Status</th>
                    <th class="px-4 py-2 border">Actions</th>
                </tr>
            </thead>
            <tbody id="leavesTableBody">
                <tr><td colspan="6" class="text-center px-4 py-2">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
// Modal
const modal = document.getElementById("leaveModal");
document.getElementById("openModalBtn").addEventListener("click", () => {
    modal.classList.remove("hidden");
    document.getElementById("leaveId").value = "";
});
document.getElementById("closeModalBtn").addEventListener("click", () => modal.classList.add("hidden"));
document.getElementById("cancelBtn").addEventListener("click", () => modal.classList.add("hidden"));
window.addEventListener("click", (e) => { if(e.target == modal) modal.classList.add("hidden"); });

// Load leaves
function loadLeaves() {
    fetch("http://localhost/hr3-microfinancial/api/leaves.php")
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById("leavesTableBody");
        tbody.innerHTML = "";
        if(!data || data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center px-4 py-2">No leaves applied.</td></tr>`;
            return;
        }
        data.forEach(lv => {
            tbody.innerHTML += `
            <tr class="text-center hover:bg-gray-50">
                <td class="px-4 py-2 border">${lv.employee_name}</td>
                <td class="px-4 py-2 border">${lv.leave_type}</td>
                <td class="px-4 py-2 border">${lv.from_date}</td>
                <td class="px-4 py-2 border">${lv.to_date}</td>
                <td class="px-4 py-2 border">${lv.status}</td>
                <td class="px-4 py-2 border">
                    <button class="editBtn bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700" data-id="${lv.id}">Edit</button>
                    <button class="deleteBtn bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700" data-id="${lv.id}">Delete</button>
                </td>
            </tr>
            `;
        });

        // Edit leave
        document.querySelectorAll(".editBtn").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = btn.dataset.id;
                fetch(`http://localhost/hr3-microfinancial/api/leaves.php?id=${id}`)
                .then(res => res.json())
                .then(lv => {
                    document.getElementById("leaveId").value = lv.id;
                    document.getElementById("employee").value = lv.employee_name;
                    document.getElementById("leaveType").value = lv.leave_type;
                    document.getElementById("fromDate").value = lv.from_date;
                    document.getElementById("toDate").value = lv.to_date;
                    modal.classList.remove("hidden");
                });
            });
        });

        // Delete leave
        document.querySelectorAll(".deleteBtn").forEach(btn => {
            btn.addEventListener("click", () => {
                if(confirm("Are you sure you want to delete this leave?")) {
                    fetch(`http://localhost/hr3-microfinancial/api/leaves.php?id=${btn.dataset.id}`, { method: "DELETE" })
                    .then(res => res.json())
                    .then(data => {
                        alert(data.message || data.error);
                        loadLeaves();
                    });
                }
            });
        });
    });
}

// Apply / Edit leave
document.getElementById("applyLeaveForm").addEventListener("submit", function(e){
    e.preventDefault();
    const id = document.getElementById("leaveId").value;
    const employee = document.getElementById("employee").value;
    const leaveType = document.getElementById("leaveType").value;
    const fromDate = document.getElementById("fromDate").value;
    const toDate = document.getElementById("toDate").value;
    const msg = document.getElementById("msg");

    if(!employee || !leaveType || !fromDate || !toDate){
        msg.innerText = "Please fill in all fields.";
        msg.classList.remove("text-green-600");
        msg.classList.add("text-red-600");
        return;
    }

    const method = id ? "PUT" : "POST";
    const url = id ? `http://localhost/hr3-microfinancial/api/leaves.php?id=${id}` : "http://localhost/hr3-microfinancial/api/leaves.php";

    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employee_name: employee, leave_type: leaveType, from_date: fromDate, to_date: toDate })
    })
    .then(res => res.json())
    .then(data => {
        if(data.message){
            msg.innerText = data.message;
            msg.classList.remove("text-red-600");
            msg.classList.add("text-green-600");
            this.reset();
            modal.classList.add("hidden");
            loadLeaves();
        } else if(data.error){
            msg.innerText = data.error;
            msg.classList.remove("text-green-600");
            msg.classList.add("text-red-600");
        }
    });
});

// Initial load
loadLeaves();
</script>
';

Layout($children);
?>
