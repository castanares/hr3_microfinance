<?php
include '../layout/Layout.php';

date_default_timezone_set('Asia/Manila');

$statuses = ["All", "Pending", "Approved", "Rejected"];

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <i class="bx bx-task text-blue-600 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">Claim Status</h1>
        </div>
        <span class="text-sm text-gray-500">Today: ' . date("F d, Y") . '</span>
    </div>

    <!-- Status Filter -->
    <div class="mb-4 max-w-sm mx-auto flex justify-between items-center gap-2">
        <label for="statusFilter" class="font-semibold text-gray-700">Filter by Status:</label>
        <select id="statusFilter" class="border rounded-lg p-2 flex-1">';
foreach ($statuses as $status) {
    $children .= '<option value="' . $status . '">' . $status . '</option>';
}
$children .= '
        </select>
    </div>

    <!-- Claims Table -->
    <div class="overflow-x-auto bg-white rounded-xl shadow p-4 max-w-5xl mx-auto">
        <table id="claimsTable" class="min-w-full border border-gray-200">
            <thead>
                <tr class="bg-gray-100 text-center">
                    <th class="px-4 py-2 border">Employee</th>
                    <th class="px-4 py-2 border">Claim Type</th>
                    <th class="px-4 py-2 border">Amount</th>
                    <th class="px-4 py-2 border">Date</th>
                    <th class="px-4 py-2 border">Status</th>
                </tr>
            </thead>
            <tbody id="claimsBody">
                <tr><td colspan="5" class="text-center px-4 py-2">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
// Fetch all claims from API
function loadClaims() {
    fetch("http://localhost/hr3-microfinancial/api/claims.php")
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById("claimsBody");
        tbody.innerHTML = "";

        if(!data || data.length === 0){
            tbody.innerHTML = `<tr><td colspan="5" class="text-center px-4 py-2">No claims submitted.</td></tr>`;
            return;
        }

        data.forEach(cl => {
            let color = cl.status === "Approved" ? "green" : cl.status === "Pending" ? "yellow" : "red";
            tbody.innerHTML += `
                <tr class="text-center hover:bg-gray-50" data-status="${cl.status}">
                    <td class="px-4 py-2 border">${cl.employee_name}</td>
                    <td class="px-4 py-2 border">${cl.claim_type}</td>
                    <td class="px-4 py-2 border">₱${parseFloat(cl.amount).toFixed(2)}</td>
                    <td class="px-4 py-2 border">${cl.claim_date}</td>
                    <td class="px-4 py-2 border font-semibold text-${color}-600">${cl.status}</td>
                </tr>`;
        });
    });
}

// Filter claims by status
document.getElementById("statusFilter").addEventListener("change", function() {
    const selected = this.value;
    const rows = document.querySelectorAll("#claimsTable tbody tr");

    rows.forEach(row => {
        if(selected === "All" || row.getAttribute("data-status") === selected) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
});

// Initial load
loadClaims();
</script>
';

Layout($children);
?>
