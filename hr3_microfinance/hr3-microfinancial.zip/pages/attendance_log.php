<?php
include '../layout/Layout.php';

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-8">
        <div class="flex items-center gap-2">
            <i class="bx bx-time-five text-indigo-600 text-3xl"></i>
            <h1 class="text-2xl font-bold text-gray-800">Attendance Log</h1>
        </div>
        <span class="text-sm text-gray-500">Updated: ' . date("F d, Y") . '</span>
    </div>

    <!-- ✅ Add Button -->
    <div class="mb-4 flex justify-end">
        <button id="openModalBtn" class="bg-indigo-600 text-white px-4 py-2 rounded-lg shadow hover:bg-indigo-700 transition">
            + Add Attendance
        </button>
    </div>

    <!-- Attendance Table -->
    <div class="bg-white p-6 rounded-xl shadow overflow-x-auto">
        <table class="w-full table-auto border-collapse border border-gray-200 text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border border-gray-200">#</th>
                    <th class="px-4 py-2 border border-gray-200">Employee Name</th>
                    <th class="px-4 py-2 border border-gray-200">Date</th>
                    <th class="px-4 py-2 border border-gray-200">Clock In</th>
                    <th class="px-4 py-2 border border-gray-200">Clock Out</th>
                    <th class="px-4 py-2 border border-gray-200">Status</th>
                </tr>
            </thead>
            <tbody id="attendanceTableBody">
                <!-- Data will be inserted dynamically -->
            </tbody>
        </table>
    </div>
</div>

<!-- ✅ Modal -->
<div id="attendanceModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-lg w-full max-w-lg p-6 relative">
        <!-- Close Button -->
        <button id="closeModalBtn" class="absolute top-3 right-3 text-gray-500 hover:text-red-600">✖</button>
        <h2 class="text-xl font-bold mb-4">Add Attendance</h2>

        <!-- Form -->
        <form id="attendanceForm" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Employee Name</label>
                <input type="text" name="employee_name" required class="w-full px-3 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Date</label>
                <input type="date" name="date" required class="w-full px-3 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Clock In</label>
                    <input type="time" name="clock_in" class="w-full px-3 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Clock Out</label>
                    <input type="time" name="clock_out" class="w-full px-3 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Status</label>
                <select name="status" required class="w-full px-3 py-2 border rounded-lg focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="Present">Present</option>
                    <option value="Late">Late</option>
                    <option value="Absent">Absent</option>
                </select>
            </div>
            <div class="flex justify-end gap-2">
                <button type="button" id="cancelModalBtn" class="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
const API_URL = "http://localhost/hr3-microfinancial/api/attendance.php";
const tableBody = document.getElementById("attendanceTableBody");

// ✅ Fetch and display data
async function loadAttendance() {
  try {
    const res = await fetch(API_URL);
    const data = await res.json();

    tableBody.innerHTML = "";
    data.forEach((row, index) => {
      const tr = document.createElement("tr");
      tr.classList.add("hover:bg-gray-50");
      tr.innerHTML = `
        <td class="px-4 py-2 border border-gray-200">${index + 1}</td>
        <td class="px-4 py-2 border border-gray-200">${row.employee_name}</td>
        <td class="px-4 py-2 border border-gray-200">${row.date}</td>
        <td class="px-4 py-2 border border-gray-200">${row.clock_in || "-"}</td>
        <td class="px-4 py-2 border border-gray-200">${row.clock_out || "-"}</td>
        <td class="px-4 py-2 border border-gray-200 font-semibold ${row.status === "Present" ? "text-green-600" : row.status === "Late" ? "text-yellow-600" : "text-red-600"}">${row.status}</td>
      `;
      tableBody.appendChild(tr);
    });
  } catch (err) {
    console.error("Error loading attendance:", err);
  }
}
loadAttendance();

// ✅ Modal controls
const openModalBtn = document.getElementById("openModalBtn");
const closeModalBtn = document.getElementById("closeModalBtn");
const cancelModalBtn = document.getElementById("cancelModalBtn");
const attendanceModal = document.getElementById("attendanceModal");

openModalBtn.addEventListener("click", () => {
  attendanceModal.classList.remove("hidden");
  attendanceModal.classList.add("flex");
});
function closeModal() {
  attendanceModal.classList.add("hidden");
  attendanceModal.classList.remove("flex");
}
closeModalBtn.addEventListener("click", closeModal);
cancelModalBtn.addEventListener("click", closeModal);

// ✅ Handle form submit (POST)
document.getElementById("attendanceForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const formData = new FormData(this);
  const payload = {};
  formData.forEach((val, key) => payload[key] = val);

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      this.reset();
      closeModal();
      loadAttendance(); // refresh table
    } else {
      alert("Error saving attendance");
    }
  } catch (err) {
    console.error("Save failed:", err);
  }
});
</script>
';

Layout($children);
?>
