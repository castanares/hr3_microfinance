<?php
include '../layout/Layout.php';

date_default_timezone_set('Asia/Manila');

// Sample shift data (replace with DB query)
$shifts = [
    ["Employee" => "Juan Dela Cruz", "Department" => "HR", "Shift" => "Morning", "Start" => "08:00 AM", "End" => "05:00 PM", "Date" => "2025-09-02"],
    ["Employee" => "Maria Santos", "Department" => "Finance", "Shift" => "Afternoon", "Start" => "01:00 PM", "End" => "10:00 PM", "Date" => "2025-09-02"],
    ["Employee" => "Pedro Reyes", "Department" => "IT", "Shift" => "Night", "Start" => "09:00 PM", "End" => "06:00 AM", "Date" => "2025-09-02"]
];

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-8">
        <div class="flex items-center gap-2">
            <i class="bx bx-calendar text-green-600 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">View Shifts</h1>
        </div>
        <span class="text-sm text-gray-500">Today: ' . date("F d, Y") . '</span>
    </div>

    <!-- Shifts Table -->
    <div class="bg-white rounded-xl shadow p-6 overflow-x-auto">
        <table class="min-w-full table-auto border-collapse border border-gray-200">
            <thead>
                <tr class="bg-gray-100">
                    <th class="px-4 py-2 border">Employee</th>
                    <th class="px-4 py-2 border">Department</th>
                    <th class="px-4 py-2 border">Shift</th>
                    <th class="px-4 py-2 border">Start Time</th>
                    <th class="px-4 py-2 border">End Time</th>
                    <th class="px-4 py-2 border">Date</th>
                </tr>
            </thead>
            <tbody>';

foreach ($shifts as $shift) {
    $children .= '
                <tr class="text-center">
                    <td class="px-4 py-2 border">' . $shift["Employee"] . '</td>
                    <td class="px-4 py-2 border">' . $shift["Department"] . '</td>
                    <td class="px-4 py-2 border">' . $shift["Shift"] . '</td>
                    <td class="px-4 py-2 border">' . $shift["Start"] . '</td>
                    <td class="px-4 py-2 border">' . $shift["End"] . '</td>
                    <td class="px-4 py-2 border">' . $shift["Date"] . '</td>
                </tr>';
}

$children .= '
            </tbody>
        </table>
    </div>
</div>
';

Layout($children);
?>
