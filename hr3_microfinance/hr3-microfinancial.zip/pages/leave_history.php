<?php
include '../layout/Layout.php';

date_default_timezone_set('Asia/Manila');

// Sample leave applications (replace with DB queries)
$leaves = [
    ["employee" => "Juan Dela Cruz", "type" => "Sick Leave", "from" => "2025-09-01", "to" => "2025-09-02", "status" => "Approved"],
    ["employee" => "Maria Santos", "type" => "Vacation Leave", "from" => "2025-09-05", "to" => "2025-09-07", "status" => "Pending"],
    ["employee" => "Pedro Reyes", "type" => "Emergency Leave", "from" => "2025-08-28", "to" => "2025-08-28", "status" => "Rejected"]
];

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <i class="bx bx-calendar-check text-indigo-600 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">Leave History</h1>
        </div>
        <span class="text-sm text-gray-500">Today: ' . date("F d, Y") . '</span>
    </div>

    <!-- Filter & Search -->
    <div class="flex flex-wrap items-center justify-between mb-4 max-w-2xl mx-auto gap-2">
        <select id="statusFilter" class="border rounded-lg p-2">
            <option value="">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
        </select>
        <input type="text" id="searchInput" placeholder="Search by employee" class="border rounded-lg p-2 flex-1">
    </div>

    <!-- Leave History Table -->
    <div class="overflow-x-auto bg-white rounded-xl shadow p-4 max-w-5xl mx-auto">
        <table id="leaveTable" class="min-w-full border border-gray-200">
            <thead>
                <tr class="bg-gray-100 text-center">
                    <th class="px-4 py-2 border">Employee</th>
                    <th class="px-4 py-2 border">Leave Type</th>
                    <th class="px-4 py-2 border">From</th>
                    <th class="px-4 py-2 border">To</th>
                    <th class="px-4 py-2 border">Status</th>
                </tr>
            </thead>
            <tbody>';
foreach ($leaves as $lv) {
    $children .= '
                <tr class="text-center hover:bg-gray-50">
                    <td class="px-4 py-2 border">' . $lv["employee"] . '</td>
                    <td class="px-4 py-2 border">' . $lv["type"] . '</td>
                    <td class="px-4 py-2 border">' . $lv["from"] . '</td>
                    <td class="px-4 py-2 border">' . $lv["to"] . '</td>
                    <td class="px-4 py-2 border">' . $lv["status"] . '</td>
                </tr>';
}
$children .= '
            </tbody>
        </table>
    </div>
</div>

<script>
// Filter by status
document.getElementById("statusFilter").addEventListener("change", function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll("#leaveTable tbody tr");
    rows.forEach(row => {
        const status = row.cells[4].innerText.toLowerCase();
        row.style.display = filter === "" || status === filter ? "" : "none";
    });
});

// Search by employee name
document.getElementById("searchInput").addEventListener("input", function() {
    const search = this.value.toLowerCase();
    const rows = document.querySelectorAll("#leaveTable tbody tr");
    rows.forEach(row => {
        const employee = row.cells[0].innerText.toLowerCase();
        row.style.display = employee.includes(search) ? "" : "none";
    });
});
</script>
';

Layout($children);
?>
