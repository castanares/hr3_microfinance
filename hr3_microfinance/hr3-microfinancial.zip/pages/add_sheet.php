<?php
include '../layout/Layout.php';
date_default_timezone_set('Asia/Manila');

$employees = ["Juan Dela Cruz", "Maria Santos", "Pedro Reyes"];
$shiftTypes = ["Morning", "Afternoon", "Night"];
$statuses = ["Pending", "Approved", "Rejected"];

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <i class="bx bx-time text-yellow-500 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">Timesheets</h1>
        </div>
        <button id="openModalBtn" class="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition">Add Timesheet</button>
    </div>

    <!-- Timesheet Table -->
    <div class="overflow-x-auto bg-white rounded-xl shadow p-4">
        <table id="timesheetTable" class="min-w-full border border-gray-200">
            <thead>
                <tr class="bg-gray-100 text-center">
                    <th class="px-4 py-2 border">Employee</th>
                    <th class="px-4 py-2 border">Date</th>
                    <th class="px-4 py-2 border">Shift</th>
                    <th class="px-4 py-2 border">Status</th>
                    <th class="px-4 py-2 border">Actions</th>
                </tr>
            </thead>
            <tbody id="timesheetBody">
                <tr><td colspan="5" class="text-center py-2">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div id="modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white rounded-xl shadow p-6 w-full max-w-md relative">
        <button id="closeModalBtn" class="absolute top-3 right-3 text-gray-500 hover:text-gray-800 text-xl">&times;</button>
        <h2 class="text-xl font-bold mb-4" id="modalTitle">Add Timesheet</h2>
        <form id="timesheetForm">
            <input type="hidden" id="tsId">
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-1">Employee</label>
                <select id="employee" class="w-full border rounded-lg p-2">
                    <option value="">Select Employee</option>';
foreach ($employees as $emp) {
    $children .= '<option value="' . $emp . '">' . $emp . '</option>';
}
$children .= '
                </select>
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-1">Date</label>
                <input type="date" id="date" class="w-full border rounded-lg p-2" value="' . date("Y-m-d") . '">
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-1">Shift</label>
                <select id="shift" class="w-full border rounded-lg p-2">
                    <option value="">Select Shift</option>';
foreach ($shiftTypes as $shift) {
    $children .= '<option value="' . $shift . '">' . $shift . '</option>';
}
$children .= '
                </select>
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-1">Status</label>
                <select id="status" class="w-full border rounded-lg p-2">
                    <option value="">Select Status</option>';
foreach ($statuses as $status) {
    $children .= '<option value="' . $status . '">' . $status . '</option>';
}
$children .= '
                </select>
            </div>
            <div class="flex justify-end gap-2 mt-4">
                <button type="button" id="cancelBtn" class="px-4 py-2 rounded-lg border hover:bg-gray-100 transition">Cancel</button>
                <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition" id="submitBtn">Save</button>
            </div>
        </form>
        <p id="msg" class="mt-2 font-semibold text-green-600"></p>
    </div>
</div>

<script>
// Modal open/close
const modal = document.getElementById("modal");
document.getElementById("openModalBtn").addEventListener("click", () => openForm());
document.getElementById("closeModalBtn").addEventListener("click", () => modal.classList.add("hidden"));
document.getElementById("cancelBtn").addEventListener("click", () => modal.classList.add("hidden"));

const form = document.getElementById("timesheetForm");
const msg = document.getElementById("msg");
const tbody = document.getElementById("timesheetBody");

// Load all timesheets
function loadTimesheets() {
    fetch("http://localhost/hr3-microfinancial/api/timesheets.php")
    .then(res => res.json())
    .then(data => {
        tbody.innerHTML = "";
        if(!data || data.length===0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-2">No timesheets found.</td></tr>`;
            return;
        }
        data.forEach(ts => {
            tbody.innerHTML += `
                <tr class="text-center hover:bg-gray-50">
                    <td class="px-4 py-2 border">${ts.employee_name}</td>
                    <td class="px-4 py-2 border">${ts.shift_date}</td>
                    <td class="px-4 py-2 border">${ts.shift_type}</td>
                    <td class="px-4 py-2 border">${ts.status}</td>
                    <td class="px-4 py-2 border flex justify-center gap-2">
                        <button onclick="editTimesheet(${ts.id})" class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600">Edit</button>
                        <button onclick="deleteTimesheet(${ts.id})" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600">Delete</button>
                    </td>
                </tr>`;
        });
    });
}

// Open form for add/edit
function openForm(ts=null) {
    modal.classList.remove("hidden");
    msg.innerText = "";
    if(ts) {
        document.getElementById("modalTitle").innerText = "Edit Timesheet";
        document.getElementById("tsId").value = ts.id;
        document.getElementById("employee").value = ts.employee_name;
        document.getElementById("date").value = ts.shift_date;
        document.getElementById("shift").value = ts.shift_type;
        document.getElementById("status").value = ts.status;
    } else {
        document.getElementById("modalTitle").innerText = "Add Timesheet";
        form.reset();
        document.getElementById("tsId").value = "";
    }
}

// Handle submit (add/update)
form.addEventListener("submit", function(e){
    e.preventDefault();
    const id = document.getElementById("tsId").value;
    const payload = {
        employee_name: document.getElementById("employee").value,
        shift_date: document.getElementById("date").value,
        shift_type: document.getElementById("shift").value,
        status: document.getElementById("status").value
    };
    const method = id ? "PUT" : "POST";
    const url = id ? `http://localhost/hr3-microfinancial/api/timesheets.php?id=${id}` : "http://localhost/hr3-microfinancial/api/timesheets.php";

    fetch(url, {
        method: method,
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        msg.innerText = data.message || data.error;
        msg.classList.toggle("text-green-600", !!data.message);
        msg.classList.toggle("text-red-600", !!data.error);
        form.reset();
        modal.classList.add("hidden");
        loadTimesheets();
    });
});

// Edit timesheet
function editTimesheet(id) {
    fetch(`http://localhost/hr3-microfinancial/api/timesheets.php?id=${id}`)
    .then(res => res.json())
    .then(ts => openForm(ts));
}

// Delete timesheet
function deleteTimesheet(id) {
    if(!confirm("Are you sure you want to delete this timesheet?")) return;
    fetch(`http://localhost/hr3-microfinancial/api/timesheets.php?id=${id}`, { method:"DELETE" })
    .then(res => res.json())
    .then(data => {
        alert(data.message || data.error);
        loadTimesheets();
    });
}

// Initial load
loadTimesheets();
</script>
';

Layout($children);
?>
