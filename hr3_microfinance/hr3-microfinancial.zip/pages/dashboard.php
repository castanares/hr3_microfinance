<?php
include '../layout/Layout.php';

$children = '
<div class="h-[130%] overflow-y-auto bg-gray-50 p-6">
    <!-- Dashboard Header -->
    <div class="flex items-center justify-between mb-8">
        <div class="flex items-center gap-2">
            <i class="bx bx-grid-alt text-indigo-600 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">HR III Dashboard</h1>
        </div>
        <span class="text-sm text-gray-500">Updated: ' . date("F d, Y") . '</span>
    </div>

    <!-- HR Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition">
            <i class="bx bx-time-five text-indigo-600 text-3xl mb-3"></i>
            <h3 class="text-xl font-semibold text-gray-800">1,024</h3>
            <p class="text-gray-500 text-sm">Attendance Records</p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition">
            <i class="bx bx-calendar text-green-600 text-3xl mb-3"></i>
            <h3 class="text-xl font-semibold text-gray-800">56</h3>
            <p class="text-gray-500 text-sm">Scheduled Shifts</p>
        </div>
       <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition">
            <i class="bx bx-time text-yellow-500 text-3xl mb-3"></i>
            <h3 id="timesheetCount" class="text-xl font-semibold text-gray-800">0</h3>
            <p class="text-gray-500 text-sm">Timesheets Pending</p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition">
            <i class="bx bx-calendar-alt text-red-600 text-3xl mb-3"></i>
            <h3 class="text-xl font-semibold text-gray-800">12</h3>
            <p class="text-gray-500 text-sm">Leave Requests</p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition">
            <i class="bx bx-receipt text-purple-600 text-3xl mb-3"></i>
            <h3 class="text-xl font-semibold text-gray-800">34</h3>
            <p class="text-gray-500 text-sm">Claims Submitted</p>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white p-6 rounded-xl shadow h-[400px] flex flex-col">
            <h2 class="text-lg font-semibold text-gray-700 mb-4">Attendance This Month</h2>
            <div class="flex-1 overflow-y-auto">
                <canvas id="attendanceChart"></canvas>
            </div>
        </div>
        <div class="bg-white p-6 rounded-xl shadow h-[400px] flex flex-col">
            <h2 class="text-lg font-semibold text-gray-700 mb-4">Leaves by Type</h2>
            <div class="flex-1 overflow-y-auto">
                <canvas id="leaveChart"></canvas>
            </div>
        </div>
    </div>
</div>


';

Layout($children);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Attendance Chart
    new Chart(document.getElementById("attendanceChart"), {
        type: "line",
        data: {
            labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
            datasets: [{
                label: "Attendance",
                data: [240, 260, 220, 300],
                borderColor: "#6366F1",
                backgroundColor: "rgba(99,102,241,0.2)",
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "top" } },
            scales: { y: { beginAtZero: true } }
        }
    });

    // Leave Chart
    new Chart(document.getElementById("leaveChart"), {
        type: "doughnut",
        data: {
            labels: ["Sick Leave", "Vacation", "Emergency", "Others"],
            datasets: [{
                label: "Leaves",
                data: [5, 3, 2, 2],
                backgroundColor: ["#34D399", "#FBBF24", "#F87171", "#A78BFA"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "bottom" } }
        }
    });

    
function loadTimesheetCount() {
    fetch('http://localhost/hr3-microfinancial/api/timesheets.php')
    .then(res => res.json())
    .then(data => {
        // Check if API returns count
        const count = data.count !== undefined ? data.count : 0;
        document.getElementById('timesheetCount').innerText = count;
    })
    .catch(err => {
        console.error('Failed to fetch timesheet count:', err);
        document.getElementById('timesheetCount').innerText = '0';
    });
}

// Initial load
loadTimesheetCount();
</script>
