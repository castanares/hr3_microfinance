<?php
include '../layout/Layout.php';
date_default_timezone_set('Asia/Manila');

$children = '
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <i class="bx bx-time text-yellow-500 text-3xl"></i>
            <h1 class="text-3xl font-bold text-gray-800">Timesheet Log</h1>
        </div>
        <span class="text-sm text-gray-500" id="lastUpdated">Updated: ' . date("F d, Y") . '</span>
    </div>

    <!-- Timesheet Table -->
    <div class="bg-white rounded-xl shadow p-6 overflow-x-auto">
        <table class="min-w-full table-auto border-collapse border border-gray-200">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border px-4 py-2 text-left">Employee</th>
                    <th class="border px-4 py-2 text-left">Date</th>
                    <th class="border px-4 py-2 text-left">Shift</th>
                    <th class="border px-4 py-2 text-left">Status</th>
                </tr>
            </thead>
            <tbody id="timesheetBody">
                <tr><td colspan="4" class="text-center py-2">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
// Fetch all timesheets from API
function loadTimesheets() {
    fetch("http://localhost/hr3-microfinancial/api/timesheets.php")
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById("timesheetBody");
        tbody.innerHTML = "";

        if (!data || data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center py-2">No timesheets found.</td></tr>`;
            return;
        }

        data.forEach(ts => {
            let statusColor = "text-gray-800";
            if (ts.status === "Approved") statusColor = "text-green-600";
            if (ts.status === "Pending") statusColor = "text-yellow-600";
            if (ts.status === "Rejected") statusColor = "text-red-600";

            tbody.innerHTML += `
                <tr class="hover:bg-gray-50">
                    <td class="border px-4 py-2">${ts.employee_name}</td>
                    <td class="border px-4 py-2">${new Date(ts.shift_date).toLocaleDateString("en-US", { month:"long", day:"numeric", year:"numeric" })}</td>
                    <td class="border px-4 py-2">${ts.shift_type}</td>
                    <td class="border px-4 py-2 font-semibold ${statusColor}">${ts.status}</td>
                </tr>
            `;
        });

        document.getElementById("lastUpdated").innerText = `Updated: ${new Date().toLocaleDateString()}`;
    })
    .catch(err => {
        const tbody = document.getElementById("timesheetBody");
        tbody.innerHTML = `<tr><td colspan="4" class="text-center py-2 text-red-600">Failed to load timesheets.</td></tr>`;
        console.error(err);
    });
}

// Initial load
loadTimesheets();
</script>
';

Layout($children);
?>
